DROP TABLE `search_index`;
DROP TABLE `search_object`;
