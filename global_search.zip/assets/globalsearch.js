$(document).ready(function() {

    var quicksearch = $('#quicksearch');

    if (quicksearch.length) {
        // Remove old quicksearch
        quicksearch.children().remove();

        // Add new quicksearch
        quicksearch.prepend($('.globalsearch').keypress(function(event) {
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                event.preventDefault();
                var params = {'search': $('.globalsearch').val(),
                    'utf8': true
                };
                window.location = STUDIP.URLHelper.getURL('plugins.php/globalesucheplugin/show/index', params);
            }
        }).show());
    }
});